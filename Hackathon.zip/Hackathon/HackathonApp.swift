//
//  HackathonApp.swift
//  Hackathon
//
//  Created by Rose DiPietro on 7/16/22.
//

import SwiftUI

@main
struct HackathonApp: App {
    var body: some Scene {
        WindowGroup {
            writeReview()
        }
    }
}

struct Previews_HackathonApp_Previews: PreviewProvider {
    static var previews: some View {
        /*@START_MENU_TOKEN@*/Text("Hello, World!")/*@END_MENU_TOKEN@*/
    }
}
